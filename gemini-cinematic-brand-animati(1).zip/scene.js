import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

// ─── Setup ───
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 12;
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
const root = document.getElementById('root') ?? document.body;
root.appendChild(renderer.domElement);

// ─── Post-processing ───
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.2);
composer.addPass(bloomPass);

// Chromatic aberration shader
const chromaticShader = {
  uniforms: {
    tDiffuse: { value: null },
    amount: { value: 0.002 }
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `uniform sampler2D tDiffuse; uniform float amount; varying vec2 vUv;
    void main(){
      vec2 offset = amount * (vUv - 0.5);
      float r = texture2D(tDiffuse, vUv + offset).r;
      float g = texture2D(tDiffuse, vUv).g;
      float b = texture2D(tDiffuse, vUv - offset).b;
      gl_FragColor = vec4(r, g, b, 1.0);
    }`
};
const chromaticPass = new ShaderPass(chromaticShader);
composer.addPass(chromaticPass);

// Film grain + vignette
const filmShader = {
  uniforms: {
    tDiffuse: { value: null },
    time: { value: 0 },
    vignetteAmount: { value: 0.8 }
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `uniform sampler2D tDiffuse; uniform float time; uniform float vignetteAmount; varying vec2 vUv;
    float rand(vec2 co){ return fract(sin(dot(co, vec2(12.9898,78.233))) * 43758.5453); }
    void main(){
      vec4 color = texture2D(tDiffuse, vUv);
      float grain = rand(vUv * time) * 0.04;
      color.rgb += grain;
      float dist = distance(vUv, vec2(0.5));
      color.rgb *= 1.0 - dist * vignetteAmount;
      gl_FragColor = color;
    }`
};
const filmPass = new ShaderPass(filmShader);
composer.addPass(filmPass);
composer.addPass(new OutputPass());

// ─── Colors ───
const PURPLE = new THREE.Color(0x8b5cf6);
const BLUE = new THREE.Color(0x3b82f6);
const SILVER = new THREE.Color(0xc0c0d0);
const CYAN = new THREE.Color(0x06b6d4);

// ─── Lights ───
const ambientLight = new THREE.AmbientLight(0x111122, 0.5);
ambientLight.name = 'ambientLight';
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0x8888ff, 0.3);
dirLight.name = 'dirLight';
dirLight.position.set(5, 5, 5);
scene.add(dirLight);

// ─── Particle System for Twin Orbs (Scene 1) ───
const PARTICLE_COUNT = 600;
const particleGeom = new THREE.BufferGeometry();
const particlePositions = new Float32Array(PARTICLE_COUNT * 3);
const particleColors = new Float32Array(PARTICLE_COUNT * 3);
const particleSizes = new Float32Array(PARTICLE_COUNT);
const particleAngles = new Float32Array(PARTICLE_COUNT);
const particleRadii = new Float32Array(PARTICLE_COUNT);
const particleSpeed = new Float32Array(PARTICLE_COUNT);
const particleSide = new Float32Array(PARTICLE_COUNT); // -1 or 1

for (let i = 0; i < PARTICLE_COUNT; i++) {
  const side = i < PARTICLE_COUNT / 2 ? -1 : 1;
  particleSide[i] = side;
  particleAngles[i] = Math.random() * Math.PI * 2;
  particleRadii[i] = 0.3 + Math.random() * 1.2;
  particleSpeed[i] = 0.5 + Math.random() * 1.5;
  particleSizes[i] = 2 + Math.random() * 4;

  const col = side < 0 ? PURPLE : BLUE;
  const lerp = Math.random() * 0.4;
  particleColors[i * 3] = THREE.MathUtils.lerp(col.r, 1, lerp);
  particleColors[i * 3 + 1] = THREE.MathUtils.lerp(col.g, 1, lerp);
  particleColors[i * 3 + 2] = THREE.MathUtils.lerp(col.b, 1, lerp);
}

particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
particleGeom.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));
particleGeom.setAttribute('size', new THREE.BufferAttribute(particleSizes, 1));

const particleMat = new THREE.ShaderMaterial({
  uniforms: {
    opacity: { value: 1.0 },
    pointTexture: { value: generateGlowTexture() }
  },
  vertexShader: `
    attribute float size;
    attribute vec3 color;
    varying vec3 vColor;
    void main() {
      vColor = color;
      vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
      gl_PointSize = size * (200.0 / -mvPos.z);
      gl_Position = projectionMatrix * mvPos;
    }
  `,
  fragmentShader: `
    uniform float opacity;
    uniform sampler2D pointTexture;
    varying vec3 vColor;
    void main() {
      vec4 tex = texture2D(pointTexture, gl_PointCoord);
      gl_FragColor = vec4(vColor, tex.a * opacity);
    }
  `,
  transparent: true,
  blending: THREE.AdditiveBlending,
  depthWrite: false
});

const particleMesh = new THREE.Points(particleGeom, particleMat);
particleMesh.name = 'twinParticles';
scene.add(particleMesh);

// ─── Core Orbs ───
const orbGeom = new THREE.SphereGeometry(0.25, 32, 32);
const orbMatA = new THREE.MeshStandardMaterial({ color: PURPLE, emissive: PURPLE, emissiveIntensity: 2, transparent: true });
const orbA = new THREE.Mesh(orbGeom, orbMatA);
orbA.name = 'orbA';
scene.add(orbA);

const orbMatB = new THREE.MeshStandardMaterial({ color: BLUE, emissive: BLUE, emissiveIntensity: 2, transparent: true });
const orbB = new THREE.Mesh(orbGeom, orbMatB);
orbB.name = 'orbB';
scene.add(orbB);

// ─── Trail Lines between orbs ───
const trailCount = 8;
const trails = [];
for (let i = 0; i < trailCount; i++) {
  const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]);
  const geom = new THREE.TubeGeometry(curve, 40, 0.015, 6, false);
  const col = new THREE.Color().lerpColors(PURPLE, BLUE, i / trailCount);
  const mat = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending });
  const mesh = new THREE.Mesh(geom, mat);
  mesh.name = `trail_${i}`;
  scene.add(mesh);
  trails.push({ mesh, mat, offset: (i / trailCount) * Math.PI * 2 });
}

// ─── Network Nodes (Scene 3) ───
const networkGroup = new THREE.Group();
networkGroup.name = 'networkGroup';
scene.add(networkGroup);

const NODE_COUNT = 60;
const nodes = [];
const nodeGeom = new THREE.SphereGeometry(0.06, 16, 16);
const nodeMat = new THREE.MeshStandardMaterial({ color: CYAN, emissive: CYAN, emissiveIntensity: 0.5, transparent: true, opacity: 0 });

for (let i = 0; i < NODE_COUNT; i++) {
  const mesh = new THREE.Mesh(nodeGeom, nodeMat.clone());
  mesh.name = `node_${i}`;
  mesh.position.set((Math.random() - 0.5) * 16, (Math.random() - 0.5) * 9, (Math.random() - 0.5) * 6);
  mesh.userData.velocity = new THREE.Vector3((Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.1);
  networkGroup.add(mesh);
  nodes.push(mesh);
}

// Network connections
const connectionMat = new THREE.LineBasicMaterial({ color: 0x4488ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending });
const connections = [];
const MAX_CONNECTIONS = 120;
for (let i = 0; i < MAX_CONNECTIONS; i++) {
  const geom = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
  const line = new THREE.Line(geom, connectionMat.clone());
  line.name = `connection_${i}`;
  line.visible = false;
  networkGroup.add(line);
  connections.push(line);
}

// ─── Background Gradient Plane ───
const bgMat = new THREE.ShaderMaterial({
  uniforms: {
    time: { value: 0 },
    opacity: { value: 0.3 }
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `
    uniform float time;
    uniform float opacity;
    varying vec2 vUv;
    void main(){
      vec2 p = vUv - 0.5;
      float d = length(p);
      vec3 c1 = vec3(0.15, 0.05, 0.3);
      vec3 c2 = vec3(0.05, 0.1, 0.25);
      vec3 col = mix(c1, c2, sin(d * 6.0 - time * 0.5) * 0.5 + 0.5);
      col *= (1.0 - d * 1.2);
      gl_FragColor = vec4(col * opacity, 1.0);
    }
  `,
  depthWrite: false
});
const bgPlane = new THREE.Mesh(new THREE.PlaneGeometry(30, 20), bgMat);
bgPlane.name = 'bgPlane';
bgPlane.position.z = -8;
scene.add(bgPlane);

// ─── Flowing Lines Background ───
const flowGroup = new THREE.Group();
flowGroup.name = 'flowLines';
scene.add(flowGroup);

for (let i = 0; i < 20; i++) {
  const points = [];
  const yBase = (Math.random() - 0.5) * 10;
  const zBase = -5 - Math.random() * 3;
  for (let j = 0; j <= 60; j++) {
    const t = j / 60;
    points.push(new THREE.Vector3((t - 0.5) * 20, yBase + Math.sin(t * Math.PI * 2 + i) * 1.5, zBase));
  }
  const curve = new THREE.CatmullRomCurve3(points);
  const geom = new THREE.TubeGeometry(curve, 60, 0.008, 4, false);
  const hue = 0.6 + Math.random() * 0.2;
  const col = new THREE.Color().setHSL(hue, 0.8, 0.5);
  const mat = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0, blending: THREE.AdditiveBlending });
  const mesh = new THREE.Mesh(geom, mat);
  mesh.name = `flowLine_${i}`;
  mesh.userData.phase = Math.random() * Math.PI * 2;
  mesh.userData.yBase = yBase;
  mesh.userData.zBase = zBase;
  flowGroup.add(mesh);
}

// ─── HTML Overlay for Text ───
const overlay = document.createElement('div');
overlay.id = 'textOverlay';
overlay.style.cssText = `
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  pointer-events: none; z-index: 10;
  display: flex; align-items: center; justify-content: center; flex-direction: column;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
`;
root.appendChild(overlay);

// Load Inter font
const fontLink = document.createElement('link');
fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;600;700&display=swap';
fontLink.rel = 'stylesheet';
document.head.appendChild(fontLink);

// ─── Glow Texture Generator ───
function generateGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 64; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(0.2, 'rgba(200,200,255,0.8)');
  gradient.addColorStop(0.5, 'rgba(100,100,255,0.3)');
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

// ─── Animation Timeline ───
const TOTAL_DURATION = 26; // seconds
const clock = new THREE.Clock();
let elapsed = 0;
let animating = true;

// Scene timing
const S1_START = 0, S1_END = 5.5;      // Particle birth + twin dance
const S2_START = 4.5, S2_END = 10;     // Logo formation
const S3_START = 9, S3_END = 16;       // Network / innovation
const S4_START = 14.5, S4_END = 22;    // Brand words
const S5_START = 20.5, S5_END = 26;    // Final logo + tagline

// Easing
function easeInOut(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
function easeOut(t) { return 1 - Math.pow(1 - t, 3); }
function easeIn(t) { return t * t * t; }
function clamp01(t) { return Math.max(0, Math.min(1, t)); }
function mapRange(t, start, end) { return clamp01((t - start) / (end - start)); }

// ─── Text Animation Helpers ───
let currentTextEl = null;

function showText(text, style = {}) {
  if (currentTextEl) currentTextEl.remove();
  const el = document.createElement('div');
  el.style.cssText = `
    color: ${style.color || '#e0e0ff'};
    font-size: ${style.size || '48px'};
    font-weight: ${style.weight || '300'};
    letter-spacing: ${style.spacing || '12px'};
    text-transform: uppercase;
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.8s ease, transform 0.8s ease;
    text-shadow: 0 0 30px rgba(139, 92, 246, 0.5), 0 0 60px rgba(59, 130, 246, 0.3);
    text-align: center;
    line-height: 1.4;
  `;
  el.textContent = text;
  overlay.appendChild(el);
  currentTextEl = el;
  requestAnimationFrame(() => {
    el.style.opacity = '1';
    el.style.transform = 'translateY(0)';
  });
  return el;
}

function hideText() {
  if (currentTextEl) {
    currentTextEl.style.opacity = '0';
    currentTextEl.style.transform = 'translateY(-20px)';
    const old = currentTextEl;
    setTimeout(() => old.remove(), 800);
    currentTextEl = null;
  }
}

function showFinalLogo() {
  if (currentTextEl) currentTextEl.remove();
  const container = document.createElement('div');
  container.style.cssText = `
    display: flex; flex-direction: column; align-items: center; gap: 16px;
    opacity: 0; transition: opacity 1.5s ease;
  `;

  const logo = document.createElement('div');
  logo.style.cssText = `
    font-size: 72px; font-weight: 200; letter-spacing: 20px; text-transform: uppercase;
    color: #f0f0ff;
    text-shadow: 0 0 40px rgba(139,92,246,0.6), 0 0 80px rgba(59,130,246,0.4), 0 0 120px rgba(6,182,212,0.2);
  `;
  logo.textContent = 'Gemini';

  const tagline = document.createElement('div');
  tagline.style.cssText = `
    font-size: 16px; font-weight: 400; letter-spacing: 6px; text-transform: uppercase;
    color: rgba(192,192,208,0.8);
    margin-top: 8px;
  `;
  tagline.textContent = 'Powering the Future';

  const line = document.createElement('div');
  line.style.cssText = `
    width: 60px; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(139,92,246,0.6), rgba(59,130,246,0.6), transparent);
    margin: 4px 0;
  `;

  container.appendChild(logo);
  container.appendChild(line);
  container.appendChild(tagline);
  overlay.appendChild(container);
  currentTextEl = container;

  requestAnimationFrame(() => { container.style.opacity = '1'; });
  return container;
}

// ─── Scene State ───
let scene1Shown = false;
let scene2Shown = false;
let brandWords = ['Innovation', 'Precision', 'Trust', 'Future-Ready'];
let currentWordIndex = -1;
let lastWordTime = 0;
let scene5Shown = false;
let fadeOutStarted = false;

// ─── Audio ───
function createAudio() {
  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const masterGain = audioCtx.createGain();
  masterGain.gain.value = 0.15;
  masterGain.connect(audioCtx.destination);

  // Pad synth
  function playPad(freq, startTime, duration) {
    const osc1 = audioCtx.createOscillator();
    const osc2 = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    osc1.type = 'sine';
    osc1.frequency.value = freq;
    osc2.type = 'sine';
    osc2.frequency.value = freq * 1.002; // slight detune

    filter.type = 'lowpass';
    filter.frequency.value = 800;
    filter.Q.value = 1;

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.3, startTime + 2);
    gain.gain.linearRampToValueAtTime(0.3, startTime + duration - 2);
    gain.gain.linearRampToValueAtTime(0, startTime + duration);

    osc1.start(startTime);
    osc2.start(startTime);
    osc1.stop(startTime + duration);
    osc2.stop(startTime + duration);
  }

  // Sub bass
  function playBass(freq, startTime, duration) {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    osc.connect(gain);
    gain.connect(masterGain);
    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.2, startTime + 1);
    gain.gain.linearRampToValueAtTime(0.2, startTime + duration - 2);
    gain.gain.linearRampToValueAtTime(0, startTime + duration);
    osc.start(startTime);
    osc.stop(startTime + duration);
  }

  // Shimmer / sparkle
  function playShimmer(freq, startTime) {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    osc.connect(gain);
    gain.connect(masterGain);
    gain.gain.setValueAtTime(0.15, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 3);
    osc.start(startTime);
    osc.stop(startTime + 3);
  }

  const now = audioCtx.currentTime;

  // Evolving pad layers
  playPad(110, now, 26);        // A2
  playPad(164.81, now + 1, 25); // E3
  playPad(220, now + 2, 24);    // A3
  playPad(329.63, now + 4, 20); // E4

  // Bass drone
  playBass(55, now, 26);

  // Shimmer accents at key moments
  playShimmer(880, now + 2);
  playShimmer(1174.66, now + 5);
  playShimmer(1318.51, now + 9);
  playShimmer(1567.98, now + 14);
  playShimmer(1760, now + 20);
  playShimmer(2093, now + 22);

  // Rising tension
  const riseOsc = audioCtx.createOscillator();
  const riseGain = audioCtx.createGain();
  const riseFilter = audioCtx.createBiquadFilter();
  riseOsc.type = 'sawtooth';
  riseOsc.frequency.setValueAtTime(80, now);
  riseOsc.frequency.linearRampToValueAtTime(160, now + 26);
  riseFilter.type = 'lowpass';
  riseFilter.frequency.setValueAtTime(200, now);
  riseFilter.frequency.linearRampToValueAtTime(600, now + 20);
  riseFilter.frequency.linearRampToValueAtTime(100, now + 26);
  riseOsc.connect(riseFilter);
  riseFilter.connect(riseGain);
  riseGain.connect(masterGain);
  riseGain.gain.setValueAtTime(0, now);
  riseGain.gain.linearRampToValueAtTime(0.05, now + 5);
  riseGain.gain.linearRampToValueAtTime(0.08, now + 18);
  riseGain.gain.linearRampToValueAtTime(0, now + 26);
  riseOsc.start(now);
  riseOsc.stop(now + 26);
}

// Start audio on first user interaction or immediately
let audioStarted = false;
function tryStartAudio() {
  if (!audioStarted) {
    audioStarted = true;
    createAudio();
  }
}

// Auto-start attempt + click fallback
setTimeout(tryStartAudio, 100);
document.addEventListener('click', tryStartAudio, { once: true });

// ─── Main Animation Loop ───
function animate() {
  const delta = clock.getDelta();
  elapsed += delta;
  const t = elapsed;

  filmPass.uniforms.time.value = t;
  bgMat.uniforms.time.value = t;

  // ── Scene 1: Twin Particle Birth ──
  const s1Progress = mapRange(t, S1_START, S1_END);

  if (s1Progress > 0 && s1Progress < 1) {
    const birthProgress = easeOut(mapRange(t, S1_START, S1_START + 2));
    const separation = birthProgress * 2.5;
    const rotSpeed = 0.8 + s1Progress * 0.5;
    const angle = t * rotSpeed;

    const ax = Math.cos(angle) * separation;
    const ay = Math.sin(angle * 0.7) * separation * 0.4;
    orbA.position.set(ax, ay, 0);
    orbB.position.set(-ax, -ay, 0);

    const scale = birthProgress * 0.5 + 0.1;
    orbA.scale.setScalar(scale);
    orbB.scale.setScalar(scale);
    orbMatA.opacity = birthProgress;
    orbMatB.opacity = birthProgress;
    orbMatA.emissiveIntensity = 2 + Math.sin(t * 3) * 0.5;
    orbMatB.emissiveIntensity = 2 + Math.sin(t * 3 + 1) * 0.5;

    // Update particles
    const positions = particleGeom.attributes.position.array;
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const side = particleSide[i];
      const center = side < 0 ? orbA.position : orbB.position;
      particleAngles[i] += delta * particleSpeed[i];
      const a = particleAngles[i];
      const r = particleRadii[i] * birthProgress;
      positions[i * 3] = center.x + Math.cos(a) * r * Math.cos(a * 0.3) ;
      positions[i * 3 + 1] = center.y + Math.sin(a) * r;
      positions[i * 3 + 2] = Math.sin(a * 0.5) * r * 0.5;
    }
    particleGeom.attributes.position.needsUpdate = true;
    particleMat.uniforms.opacity.value = birthProgress * 0.8;

    // Trails
    trails.forEach((trail, i) => {
      const tOff = trail.offset;
      const pts = [];
      for (let j = 0; j < 4; j++) {
        const frac = j / 3;
        const a = angle - frac * 0.5 + tOff * 0.1;
        const sep = separation * (0.3 + frac * 0.7);
        const px = THREE.MathUtils.lerp(orbA.position.x, orbB.position.x, frac) + Math.sin(a + tOff) * 0.3;
        const py = THREE.MathUtils.lerp(orbA.position.y, orbB.position.y, frac) + Math.cos(a + tOff) * 0.3;
        pts.push(new THREE.Vector3(px, py, Math.sin(a) * 0.2));
      }
      const curve = new THREE.CatmullRomCurve3(pts);
      trail.mesh.geometry.dispose();
      trail.mesh.geometry = new THREE.TubeGeometry(curve, 40, 0.015, 6, false);
      trail.mat.opacity = birthProgress * 0.3;
    });

    bloomPass.strength = 1.5 + birthProgress * 0.5;
  }

  // Fade out scene 1 elements
  const s1Fade = 1 - easeIn(mapRange(t, S1_END - 1, S1_END));
  if (t > S1_END - 1) {
    particleMat.uniforms.opacity.value *= s1Fade;
    orbMatA.opacity = s1Fade;
    orbMatB.opacity = s1Fade;
    trails.forEach(tr => tr.mat.opacity *= s1Fade);
  }
  if (t > S1_END + 0.5) {
    particleMesh.visible = false;
    orbA.visible = false;
    orbB.visible = false;
    trails.forEach(tr => tr.mesh.visible = false);
  }

  // ── Scene 2: Logo Text ──
  const s2Progress = mapRange(t, S2_START, S2_END);
  if (s2Progress > 0 && !scene2Shown && t > S2_START + 1) {
    scene2Shown = true;
    showText('Gemini', { size: '80px', weight: '200', spacing: '24px', color: '#f0f0ff' });
  }
  if (scene2Shown && t > S3_START - 0.5 && !scene1Shown) {
    scene1Shown = true;
    hideText();
  }

  // Flow lines for scene 2
  if (s2Progress > 0) {
    const flowOpacity = Math.min(1, s2Progress * 2) * (1 - easeIn(mapRange(t, S2_END - 1, S2_END + 1)));
    flowGroup.children.forEach((line, i) => {
      line.material.opacity = flowOpacity * 0.15;
      // Animate flow
      const pts = [];
      const yb = line.userData.yBase;
      const zb = line.userData.zBase;
      const ph = line.userData.phase;
      for (let j = 0; j <= 60; j++) {
        const f = j / 60;
        pts.push(new THREE.Vector3(
          (f - 0.5) * 20,
          yb + Math.sin(f * Math.PI * 2 + ph + t * 0.5) * 1.5,
          zb
        ));
      }
      const curve = new THREE.CatmullRomCurve3(pts);
      line.geometry.dispose();
      line.geometry = new THREE.TubeGeometry(curve, 60, 0.008, 4, false);
    });
  }

  // ── Scene 3: Network ──
  const s3Progress = mapRange(t, S3_START, S3_END);
  if (s3Progress > 0 && s3Progress < 1) {
    const netOpacity = easeInOut(Math.min(1, s3Progress * 3)) * (1 - easeIn(mapRange(t, S3_END - 1.5, S3_END)));

    // Move nodes
    nodes.forEach((node, i) => {
      node.position.add(node.userData.velocity.clone().multiplyScalar(delta));
      // Bounce
      ['x', 'y', 'z'].forEach((axis, ai) => {
        const limit = [8, 4.5, 3][ai];
        if (Math.abs(node.position[axis]) > limit) {
          node.userData.velocity[axis] *= -1;
        }
      });
      node.material.opacity = netOpacity * 0.8;
      node.material.emissiveIntensity = 0.5 + Math.sin(t * 2 + i) * 0.3;
    });

    // Update connections
    let connIdx = 0;
    const maxDist = 3.5;
    for (let i = 0; i < NODE_COUNT && connIdx < MAX_CONNECTIONS; i++) {
      for (let j = i + 1; j < NODE_COUNT && connIdx < MAX_CONNECTIONS; j++) {
        const dist = nodes[i].position.distanceTo(nodes[j].position);
        if (dist < maxDist) {
          const line = connections[connIdx];
          const pos = line.geometry.attributes.position;
          pos.setXYZ(0, nodes[i].position.x, nodes[i].position.y, nodes[i].position.z);
          pos.setXYZ(1, nodes[j].position.x, nodes[j].position.y, nodes[j].position.z);
          pos.needsUpdate = true;
          line.visible = true;
          line.material.opacity = netOpacity * (1 - dist / maxDist) * 0.3;
          connIdx++;
        }
      }
    }
    for (let i = connIdx; i < MAX_CONNECTIONS; i++) {
      connections[i].visible = false;
    }
  } else {
    nodes.forEach(n => n.material.opacity = 0);
    connections.forEach(c => c.visible = false);
  }

  // ── Scene 4: Brand Words ──
  const s4Progress = mapRange(t, S4_START, S4_END);
  if (s4Progress > 0 && s4Progress < 1) {
    const wordDuration = (S4_END - S4_START) / brandWords.length;
    const newWordIndex = Math.min(Math.floor(s4Progress * brandWords.length), brandWords.length - 1);

    if (newWordIndex !== currentWordIndex) {
      currentWordIndex = newWordIndex;
      hideText();
      setTimeout(() => {
        if (currentWordIndex < brandWords.length) {
          showText(brandWords[currentWordIndex], {
            size: '56px',
            weight: '300',
            spacing: '16px',
            color: '#e8e0ff'
          });
        }
      }, 400);
    }
  }

  if (t > S4_END - 0.5 && currentWordIndex >= 0 && !scene5Shown) {
    hideText();
    currentWordIndex = -1;
  }

  // ── Scene 5: Final Logo ──
  const s5Progress = mapRange(t, S5_START, S5_END);
  if (s5Progress > 0 && !scene5Shown) {
    scene5Shown = true;
    setTimeout(() => showFinalLogo(), 500);
  }

  if (scene5Shown) {
    bloomPass.strength = 1.5 + Math.sin(t * 2) * 0.3;
    bgMat.uniforms.opacity.value = 0.4 + Math.sin(t * 1.5) * 0.1;
  }

  // Final fade to black
  if (t > S5_END - 2 && !fadeOutStarted) {
    fadeOutStarted = true;
    if (currentTextEl) {
      currentTextEl.style.transition = 'opacity 2s ease';
      currentTextEl.style.opacity = '0';
    }
  }

  // ── Global effects ──
  filmPass.uniforms.vignetteAmount.value = 0.7 + Math.sin(t * 0.5) * 0.1;
  chromaticPass.uniforms.amount.value = 0.001 + Math.sin(t * 0.3) * 0.001;

  // Camera subtle motion
  camera.position.x = Math.sin(t * 0.15) * 0.3;
  camera.position.y = Math.cos(t * 0.1) * 0.2;
  camera.lookAt(0, 0, 0);

  composer.render();

  // Loop
  if (t >= TOTAL_DURATION) {
    elapsed = 0;
    scene1Shown = false;
    scene2Shown = false;
    currentWordIndex = -1;
    scene5Shown = false;
    fadeOutStarted = false;
    particleMesh.visible = true;
    orbA.visible = true;
    orbB.visible = true;
    trails.forEach(tr => tr.mesh.visible = true);
    if (currentTextEl) { currentTextEl.remove(); currentTextEl = null; }
  }
}

renderer.setAnimationLoop(animate);

// ─── Resize ───
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
});