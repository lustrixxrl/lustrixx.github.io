# Gemini cinematic brand animation

Created with [Omma](https://omma.build)

## Setup

Open `index.html` in your browser, or:

```bash
npx serve .
```
